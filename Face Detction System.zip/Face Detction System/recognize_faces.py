import cv2

def recognize_faces():
    # Load the trained face recognizer model using LBPH (Local Binary Patterns Histograms) 
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read('trained_model.xml')

    # Load the label mapping
    label_mapping = {}
    with open('label_mapping.txt', 'r') as file:
        for line in file:
            label, user_name = line.strip().split(':')
            label_mapping[int(label)] = user_name

    # Open the camera
    capture = cv2.VideoCapture(0)

    while True:
        # Read the current frame from the camera
        ret, frame = capture.read()

        if not ret:
            break

        # Convert the frame to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the frame
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5, minSize=(100, 100))

        # Process each detected face
        for (x, y, w, h) in faces:
            # Resize the face region to match the training image size
            face = cv2.resize(gray[y:y+h, x:x+w], (100, 100))

            # Recognize the face
            label, confidence = recognizer.predict(face)

            # Get the corresponding user name
            user_name = label_mapping.get(label, "Unknown")

            # Draw a rectangle around the face
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

            # Display the user ID and name on top of the rectangle
            cv2.putText(frame, f"ID: {label}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            cv2.putText(frame, f"Name: {user_name}", (x, y+h+25), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
      # Display the frame
        cv2.imshow("Face Recognition", frame)

        # Exit the loop if 'q' is pressed
        if cv2.waitKey(1)==13:
            break

    # Release the capture and close the window
    capture.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    recognize_faces()
