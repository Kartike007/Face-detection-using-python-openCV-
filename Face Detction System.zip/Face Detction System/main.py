import tkinter as tk
import subprocess

def capture_images():
    # Open the face capture file
    subprocess.run(["python", "face_capture.py"])

def train_model():
    # Open the face training file
    subprocess.run(["python", "train_images.py"])

def open_face_recognition():
    # Open the face recognition file
    subprocess.run(["python", "recognize_faces.py"])

def main():
    root = tk.Tk()
    root.title("Face Recognition Main GUI")

    # Create a frame for the buttons
    button_frame = tk.Frame(root)
    button_frame.pack(pady=20)

    # Create buttons
    capture_button = tk.Button(button_frame, text="Capture Images", command=capture_images)
    capture_button.grid(row=0, column=0, padx=10)

    train_button = tk.Button(button_frame, text="Train Model", command=train_model)
    train_button.grid(row=0, column=1, padx=10)

    recognition_button = tk.Button(button_frame, text="Open Face Recognition", command=open_face_recognition)
    recognition_button.grid(row=0, column=2, padx=10)

    root.mainloop()

if __name__ == "__main__":
    main()
