import os
import cv2
import numpy as np

def train_images(capture_directory):
    images = []
    labels = []
    label_mapping = {}

    for root, dirs, files in os.walk(capture_directory):
        for file in files:
            if file.endswith('.jpg'):
                file_path = os.path.join(root, file)
                label = file.split('_')[1]
                user_name = file.split('_')[2]

                if label not in label_mapping:
                    label_mapping[label] = user_name

                # Load the image and convert it to grayscale
                img = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)

                # Resize the image to a fixed size
                img = cv2.resize(img, (100, 100))

                images.append(img)
                labels.append(int(label))

    # Convert the lists to NumPy arrays
    images = np.array(images, dtype=np.uint8)
    labels = np.array(labels, dtype=np.int32)

    # Create the LBPH face recognizer
    recognizer = cv2.face.LBPHFaceRecognizer_create()

    # Train the recognizer with the images and labels
    recognizer.train(images, labels)

    # Save the trained recognizer to a file
    recognizer.save('trained_model.xml')

    # Save the label mapping to a file
    with open('label_mapping.txt', 'w') as file:
        for label, user_name in label_mapping.items():
            file.write(f"{label}:{user_name}\n")

    print("Training completed successfully!")


if __name__ == "__main__":
    capture_directory = 'captured_images'
    train_images(capture_directory)
